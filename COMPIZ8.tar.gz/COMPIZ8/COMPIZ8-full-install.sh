#!/bin/bash

cd COMPIZ8-001 &&
rm -rf compiz-core &&
tar xvfz compiz-core.tar.gz &&
cd compiz-core &&
makepkg --noconfirm -s &&
sudo pacman --noconfirm -U ./compiz-core*.tar &&
sudo pacman --noconfirm -U ./compiz-gtk*.tar &&
cd .. &&
rm -rf compiz-core &&
cd .. &&

cd COMPIZ8-002 &&
rm -rf compiz-bcop &&
tar xvfz compiz-bcop.tar.gz &&
cd compiz-bcop &&
makepkg --noconfirm -s &&
sudo pacman --noconfirm -U ./compiz-bcop*.tar &&
cd .. &&
rm -rf compiz-bcop &&
cd .. &&

cd COMPIZ8-003 &&
rm -rf compiz-fusion-plugins-main &&
tar xvfz compiz-fusion-plugins-main.tar.gz &&
cd compiz-fusion-plugins-main &&
makepkg --noconfirm -s &&
sudo pacman --noconfirm -U ./compiz-fusion-plugins-main*.tar &&
cd .. &&
rm -rf compiz-fusion-plugins-main &&
cd .. &&

cd COMPIZ8-004 &&
rm -rf compiz-fusion-plugins-extra &&
tar xvfz compiz-fusion-plugins-extra.tar.gz &&
cd compiz-fusion-plugins-extra &&
makepkg --noconfirm -s &&
sudo pacman --noconfirm -U ./compiz-fusion-plugins-extra*.tar &&
cd .. &&
rm -rf compiz-fusion-plugins-extra &&
cd .. &&

cd COMPIZ8-005 &&
rm -rf emerald &&
tar xvfz emerald.tar.gz &&
cd emerald &&
makepkg --noconfirm -s &&
sudo pacman --noconfirm -U ./emerald*.tar &&
cd .. &&
rm -rf emerald &&
cd .. &&

cd COMPIZ8-006 &&
rm -rf libcompizconfig &&
tar xvfz libcompizconfig.tar.gz &&
cd libcompizconfig &&
makepkg --noconfirm -s &&
sudo pacman --noconfirm -U ./libcompizconfig*.tar &&
cd .. &&
rm -rf libcompizconfig &&
cd .. &&

cd COMPIZ8-007 &&
rm -rf compizconfig-python &&
tar xvfz compizconfig-python.tar.gz &&
cd compizconfig-python &&
makepkg --noconfirm -s &&
sudo pacman --noconfirm -U ./compizconfig-python*.tar &&
cd .. &&
rm -rf compizconfig-python &&
cd .. &&

cd COMPIZ8-008 &&
rm -rf ccsm &&
tar xvfz ccsm.tar.gz &&
cd ccsm &&
makepkg --noconfirm -s &&
sudo pacman --noconfirm -U ./ccsm*.tar &&
cd .. &&
rm -rf ccsm &&
cd .. &&

cd COMPIZ8-009 &&
rm -rf emerald-themes &&
tar xvfz emerald-themes.tar.gz &&
cd emerald-themes &&
makepkg --noconfirm -s &&
sudo pacman --noconfirm -U ./emerald-themes*.tar &&
cd .. &&
rm -rf emerald-themes &&
cd ..


